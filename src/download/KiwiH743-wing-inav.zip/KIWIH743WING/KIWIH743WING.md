# Kiwi H743 Wing

STM32H743 fixed-wing flight controller. Target: `KIWIH743WING`. Board identifier: `KH7W`.

Pin mapping is derived from the ArduPilot hwdef `KiwiH743-wing`.

## Hardware

| Function | Device | Bus / pins |
|---|---|---|
| IMU 1 | ICM42688P | SPI1 (PA5/PA6/PA7), CS PB2 |
| IMU 2 | ICM45686 | SPI4 (PE12/PE13/PE14), CS PE15 |
| Baro | BMP388 | I2C1 (PB6/PB7), 0x76 |
| External I2C (mag, pitot, rangefinder) | | I2C2 (PB10/PB11) |
| Blackbox | SD card | SDMMC1 4-bit (PC8-PC12, PD2) |
| OSD | onboard STM32G4 (OpenPixelOSD), MSP DisplayPort | UART8 (PE1/PE0), defaults to MSP DisplayPort 115200, `osd_video_system BF43COMPAT` |
| USB | VCP | PA11/PA12 |
| LED | active-high | PD11 |
| Buzzer | passive, PWM | PA15 (TIM2_CH1) |
| HSE | 16 MHz | |

## UARTs

| INAV port | Pins (TX/RX) | Default |
|---|---|---|
| UART1 | PB14 / PB15 | |
| UART2 | PD5 / PD6 | VTX Tramp on TX |
| UART3 | PD8 / PD9 | |
| UART4 | PD1 / PD0 | |
| UART5 | PB13 / PB12 | |
| UART6 | PC6 / PC7 | Serial RX (CRSF) |
| UART7 | PE8 / PE7 | (RTS/CTS on PE9/PE10 unused) |
| UART8 | PE1 / PE0 | MSP DisplayPort (onboard OSD) |

## Outputs

15 outputs across four timers. Outputs sharing a timer must be of the same type (all motors or all servos).

| Output | Pin | Timer |
|---|---|---|
| S1 | PA10 | TIM1_CH3 |
| S2 | PA9 | TIM1_CH2 |
| S3 | PA8 | TIM1_CH1 |
| S4 | PD15 | TIM4_CH4 (no DMA, no DSHOT) |
| S5 | PD14 | TIM4_CH3 |
| S6 | PD13 | TIM4_CH2 |
| S7 | PD12 | TIM4_CH1 |
| S8 | PB1 | TIM3_CH4 |
| S9 | PB0 | TIM3_CH3 |
| S10 | PB4 | TIM3_CH1 |
| S11 | PB5 | TIM3_CH2 |
| S12 | PA3 | TIM5_CH4 |
| S13 | PA2 | TIM5_CH3 |
| S14 | PA1 | TIM5_CH2 |
| S15 | PA0 | TIM5_CH1 |

## ADC

| Channel | Pin | Default scale |
|---|---|---|
| VBAT | PC5 | `vbat_scale` 2100 (21:1 divider) |
| Current | PC4 | `current_meter_scale` 172 (58.26 A/V) |
| RSSI | PC1 | spare ADC 1 |
| Airspeed | PC0 | spare ADC 2 |

## PINIO

| Box | Pin | Board function |
|---|---|---|
| USER1 | PE2 | camera switch |
| USER2 | PD3 | relay 1 |
| USER3 | PD4 | relay 2 |
| USER4 | PD7 | aux 1 |

PB3 (aux 2), PE5 (aux 3) and CAN1 (PB8/PB9) are not used by INAV.

## Notes

* IMU alignment is `CW90_DEG_FLIP` for both sensors, translated from ArduPilot `ROTATION_YAW_270`. Verify on the bench.
* The 32.768 kHz IMU CLKIN on PE6 is not driven by INAV; both IMUs run on their internal oscillators.
* OSD reset (PE3) and OSD boot (PC13) lines are left untouched.
* VTX (Tramp, 4.9 to 7.2 GHz, 4 W): INAV has no custom band table. INAV band A equals vendor band I and INAV band E equals vendor band K. Other vendor bands are not reachable from INAV. Power table is 25 mW, 2 W, 4 W (core change in `vtx_tramp.c`).
* SD card lines have no external pull-ups, so the target defines `SDCARD_SDIO_PULLUP` (core change in `sdmmc_sdio_hal.c`) to enable the MCU internal pull-ups, as ArduPilot does.
* Stock INAV 9.1 lets the MSP VTX driver (for DJI/HDZero goggles) replace an already registered Tramp or SmartAudio driver whenever MSP DisplayPort OSD is enabled. `vtx_msp.c` now keeps the serial VTX driver (core change).
* Tramp baud is swept 9120 to 10080 when the VTX does not answer at 9600 (core change in `vtx_tramp.c`).
* Do not flash this target as a raw `.bin` over DFU. The config sector sits at 0x08020000 between the vector table and the code, and `objcopy -O binary` fills that gap with zeros, which wipes all settings. Flash the `.hex` (Configurator or STM32CubeProgrammer).
* OpenPixelOSD holds a 256 character Betaflight font and ignores the DisplayPort font page bit, so INAV's own 512 character font cannot be used. The target defaults `osd_video_system` to `BF43COMPAT`, where INAV remaps all symbols, horizon and arrows onto the Betaflight font. Configurator font upload only writes to a MAX7456 and is a no-op here.
* The target defines `MSP_OSD_ALWAYS_ACTIVE`. Stock INAV only transmits MSP DisplayPort after the OSD device sends an MSP request, and OpenPixelOSD never does. The define keeps the link active without that handshake.
